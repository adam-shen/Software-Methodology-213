package chess;

public enum Color {
    WHITE, BLACK;
}
